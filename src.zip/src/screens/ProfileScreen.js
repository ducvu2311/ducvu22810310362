import React from "react";
import { 
  View, Text, Image, TouchableOpacity, StyleSheet 
} from "react-native";

const ProfileScreen = () => {
  return (
    <View style={styles.container}>
      {/* Ảnh bìa */}
      <Image 
        source={require("../assets/images/cover.jpg")} 
        style={styles.coverImage} 
      />

      {/* Ảnh đại diện */}
      <Image 
        source={require("../assets/images/avatar.jpg")} 
        style={styles.avatar} 
      />

      {/* Thông tin cá nhân */}
      <Text style={styles.name}>Duc Vu</Text>
      <Text style={styles.role}>Mobile Developer</Text>
      <Text style={styles.description}>
        I have above 5 years of experience in native mobile apps development, now I am learning React Native.
      </Text>

      {/* Nút Đăng Xuất */}
      <TouchableOpacity style={styles.signOutButton}>
        <Text style={styles.signOutText}>Sign Out</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: "center", backgroundColor: "#f8f8f8" },
  coverImage: { width: "100%", height: 150 },
  avatar: { 
    width: 100, 
    height: 100, 
    borderRadius: 50, 
    borderWidth: 3, 
    borderColor: "#fff", 
    marginTop: -50 
  },
  name: { fontSize: 22, fontWeight: "bold", marginTop: 10 },
  role: { fontSize: 16, color: "#007bff", marginVertical: 5 },
  description: { 
    fontSize: 14, 
    color: "#666", 
    textAlign: "center", 
    marginHorizontal: 30, 
    marginVertical: 10 
  },
  signOutButton: { 
    backgroundColor: "#ff9900", 
    paddingVertical: 10, 
    paddingHorizontal: 30, 
    borderRadius: 10, 
    marginTop: 20 
  },
  signOutText: { color: "#fff", fontSize: 16, fontWeight: "bold" }
});

export default ProfileScreen;
