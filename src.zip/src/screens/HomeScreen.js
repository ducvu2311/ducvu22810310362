import React, { useState } from "react";
import { 
  View, Text, TextInput, TouchableOpacity, FlatList, Image, StyleSheet 
} from "react-native";
import { Ionicons } from "@expo/vector-icons";

const categories = [
  { id: "1", name: "Pizza", image: require("../assets/images/pizza.jpg") },
  { id: "2", name: "Burgers", image: require("../assets/images/burger.jpg") },
  { id: "3", name: "Steak", image: require("../assets/images/steak.jpg") },
];

const foodItems = [
  { id: "1", name: "burger", price: "1$", image: require("../assets/images/burger.jpg") },
  { id: "2", name: "steak", price: "3$", image: require("../assets/images/steak.jpg") },
  { id: "3", name: "pizza", price: "5$", image: require("../assets/images/pizza.jpg") },
];

const HomeScreen = () => {
  const [search, setSearch] = useState("");

  return (
    <View style={styles.container}>
      {/* Banner */}
      <Image source={require("../assets/images/banner.jpg")} style={styles.banner} />

      {/* Thanh tìm kiếm */}
      <View style={styles.searchContainer}>
        <Ionicons name="search" size={20} color="#888" style={styles.searchIcon} />
        <TextInput 
          style={styles.searchInput} 
          placeholder="Search for meals or area" 
          value={search} 
          onChangeText={setSearch} 
        />
        <TouchableOpacity>
          <Ionicons name="filter" size={24} color="#ff9900" />
        </TouchableOpacity>
      </View>

      {/* Danh mục món ăn */}
      <Text style={styles.sectionTitle}>Top Categories</Text>
      <FlatList
        data={categories}
        horizontal
        showsHorizontalScrollIndicator={false}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.categoryItem}>
            <Image source={item.image} style={styles.categoryImage} />
            <Text style={styles.categoryText}>{item.name}</Text>
          </View>
        )}
      />

      {/* Món ăn phổ biến */}
      <Text style={styles.sectionTitle}>Popular Items</Text>
      <FlatList
        data={foodItems}
        horizontal
        showsHorizontalScrollIndicator={false}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.foodItem}>
            <Image source={item.image} style={styles.foodImage} />
            <Text style={styles.foodName}>{item.name}</Text>
            <Text style={styles.foodPrice}>{item.price}</Text>
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff", padding: 20 },
  banner: { width: "100%", height: 150, borderRadius: 10, marginBottom: 20 },
  searchContainer: { flexDirection: "row", alignItems: "center", backgroundColor: "#f0f0f0", borderRadius: 10, padding: 10, marginBottom: 20 },
  searchIcon: { marginRight: 10 },
  searchInput: { flex: 1, fontSize: 16 },
  sectionTitle: { fontSize: 18, fontWeight: "bold", marginBottom: 10 },
  categoryItem: { alignItems: "center", marginRight: 15 },
  categoryImage: { width: 80, height: 80, borderRadius: 40 },
  categoryText: { marginTop: 5, fontSize: 14, fontWeight: "bold" },
  foodItem: { backgroundColor: "#fff", padding: 10, borderRadius: 10, marginRight: 15, shadowColor: "#000", shadowOpacity: 0.1, shadowOffset: { width: 0, height: 2 }, shadowRadius: 5 },
  foodImage: { width: 120, height: 100, borderRadius: 10 },
  foodName: { fontSize: 16, fontWeight: "bold", marginTop: 5 },
  foodPrice: { color: "#ff9900", fontSize: 14, fontWeight: "bold", marginTop: 2 },
});

export default HomeScreen;
